import com.alibaba.jvm.sandbox.api.Information;
import com.alibaba.jvm.sandbox.api.Module;
import com.alibaba.jvm.sandbox.api.ProcessController;
import com.alibaba.jvm.sandbox.api.annotation.Command;
import com.alibaba.jvm.sandbox.api.listener.ext.Advice;
import com.alibaba.jvm.sandbox.api.listener.ext.AdviceListener;
import com.alibaba.jvm.sandbox.api.listener.ext.EventWatchBuilder;
import com.alibaba.jvm.sandbox.api.resource.ModuleEventWatcher;
import com.alibaba.jvm.sandbox.module.debug.ParamSupported;
import org.kohsuke.MetaInfServices;

import javax.annotation.Resource;
import java.util.Map;

@MetaInfServices(Module.class)
@Information(id = "ceshiren", author = "ceshiren.com")
public class csrHookModule extends ParamSupported implements Module {

    @Resource
    private ModuleEventWatcher moduleEventWatcher;

    @Command("csrhook")
    public void csrHook(final Map<String, String> param) {
        // todo:将传入参数优化为数组，方便一次进行多个规则的设置
        final String className = getParameter(param, "class");
        final String methodName = getParameter(param, "method");
        final String type = getParameter(param, "type");
        new EventWatchBuilder(moduleEventWatcher)
                .onClass(className)
                .onBehavior(methodName)
                .onWatch(new AdviceListener() {
                    @Override
                    protected void before(Advice advice) throws Throwable {
                        if (type.equals("args")) {
                            // 修改方法传入的参数
                            // todo:将传入参数类型转换为数组，方便传递位置和修改内容
                            // todo:优化为接受多组参数修改，方便进行多个参数的修改
                            final String argsData = getParameter(param, "param_data");
                            advice.changeParameter(0, argsData);
                        }
                        if (type.equals("direct_return")) {
                            // 进入方法后就直接返回，return传递来的返回值，可以将方法中本身的逻辑mock掉
                            // todo:优化为支持多种数据结构，尤其是json
                            final String returnData = getParameter(param, "param_data");
                            ProcessController.returnImmediately(returnData);
                        }
                    }
                });
    }

}
import importlib
import json

import jmespath as jmespath
import pytest
from jsonpath import jsonpath

from mtf.core.logger import log


def pytest_generate_tests(metafunc):
    if "fixture1" in metafunc.fixturenames:
        metafunc.parametrize("fixture1", [
            1,
            2,
        ])
    if "fixture2" in metafunc.fixturenames:
        metafunc.parametrize("fixture2", [
            1, 2
        ])


def test_foobar(fixture1, fixture2):
    pass
    # assert fixture1 == fixture2


def test_args():
    def demo(*args, **kwargs):
        print(args)
        print(kwargs)
        print("")

    demo(1)
    demo(1, 2, 3)
    demo(a=1, b=2)


def test_json_path():
    content = """
    {
      "a":
      {
        "b": 2,
        "c": "cc"
        },
      "d":
      [{
        "b": 1,
        "c": "cc"
        }]
    }
    """
    json_object = json.loads(content)

    def path(x):
        print(x)
        print(jsonpath(json_object, x))

    def jme(x):
        print(x)
        print(jmespath.search(x, json_object))

    path('$..b')
    path('$..a')
    path('$.a[?(@.b==2)]')
    path('$..a[*][?(@.b==2)]')
    # jme('a[? b == 2 ].c')
    path('$..d[?(@.b)]')
    path('$..d[?(@.b==1)]')
    jme("d[?b==`1`]")
    path('$..d[?(@.b==2)]')

    print(jsonpath([{'a': 1}, {'a': 2}], '$..[?(@.a==2)]'))
    print(jsonpath({'a': 1, "b": 2}, '$..[?(@.a==1)]'))

    dict = {'first_line_format': '', 'method': 'get', 'scheme': 'http', 'host': '127.0.0.1', 'port': 80, 'path': '/',
            'http_version': 2.0, 'headers': {}, 'content': None, 'trailers': None, 'timestamp_start': None,
            'timestamp_end': None}

    print(jsonpath([dict], '$..[?(@.method=="get")]'))
    print(json.dumps([dict]))
    print(jsonpath(json.dumps([dict]), '$..[?(@.method=="get")]'))


def test_load():
    r = importlib.import_module("random")
    globals()['random'] = r
    print(r.random())
    print(globals()['random'])
    print(globals()['random'].random())
    print(random)

    t = importlib.import_module("mtf.core.testcase")
    print(t)
    print(getattr(t, 'TestCase')([], None))


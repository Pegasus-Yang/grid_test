from mtf.core.data_treating.text_file import TextFile

data = """
begin test a
command bbb1
command bbb2
begin test c
command bbb1
command bbb1
"""
pattern = [
    {"pattern":
         ["begin test (?P<begin_test>.)"],
     "sub":
         [
             {
                 "pattern": ["command (?P<command>bbb.)"]
             }
         ]
     }
]


def test_text_file():
    expect_result = [
        {'begin_test': 'a', 'command': 'bbb1'},
        {'begin_test': 'a', 'command': 'bbb2'},
        {'begin_test': 'c', 'command': 'bbb1'},
        {'begin_test': 'c', 'command': 'bbb1'}
    ]
    parse_result = TextFile().parse(data, pattern)
    assert expect_result == parse_result

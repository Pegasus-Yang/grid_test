# -*- coding: utf-8 -*-
import jsonpath
import regex as re


class TextFile:
    """
    将 txt 结构化成 python 数据格式
    """

    def __init__(self):
        self._raw_datas = ""
        self._regulars = {}

    def __handle_log(self, data, regulars: list):
        result = []
        count = 0
        for regular in regulars:
            expr = "|".join(regular["pattern"])
            find_results_iter = re.finditer(expr, data)
            try:
                pre_split_key = next(find_results_iter)
            except StopIteration:
                continue
            if regular.get("sub"):
                # 第一次运行丢掉第一块数据
                if count == 0:
                    data = data.split(pre_split_key.group(), 1)[1]
                    count = 1
                for split_key in find_results_iter:
                    split_datas = data.split(split_key.group(), 1)
                    pre_results = self.__handle_log(split_datas[0], regular['sub'])
                    result += self._update_if_not_none(pre_results, self._get_groupdict(pre_split_key))
                    pre_split_key = split_key
                    data = split_datas[1]
                # 处理最后一次
                pre_results = self.__handle_log(data, regular['sub'])
                result += self._update_if_not_none(pre_results, self._get_groupdict(pre_split_key))
            else:
                result.append(self._get_groupdict(pre_split_key))
                result += [self._get_groupdict(i) for i in find_results_iter]
        return result

    def _get_groupdict(self, re_match_data):
        return self._delete_none(re_match_data.groupdict())

    def _delete_none(self, data):
        """
        删除 value 为 none 的字段
        :param data:
        :return:
        """
        # 如果存在 None 就删除
        for key in list(data.keys()):
            if not data.get(key):
                del data[key]
        return data

    def _update_if_not_none(self, pre_results, pre_split_key: dict):
        """
        更新数据，删除 none 数据
        :param pre_results:
        :param pre_split_key:
        :return:
        """
        result = []
        for pre_result in pre_results:
            pre_split_key_copy = pre_split_key.copy()
            pre_split_key_copy.update(pre_result)
            result.append(pre_split_key_copy)
        if not result:
            return [pre_split_key]
        else:
            return result

    def parse(self, raw_datas, regular):
        """
        将 log 结构化
        :return:
        """
        self._regulars = regular
        format_data = self.__handle_log(raw_datas, self._regulars)
        self._format_data = self._update_data(format_data)
        return self._format_data

    def get_format_data(self):
        return self._format_data

    def read_by_jsonpath(self, jsonpath_expr):
        return jsonpath.jsonpath(self._format_data, jsonpath_expr)

    def _update_data(self, format_data):
        """
        对结构化后的数据进行二次处理
        :param data:
        :return:
        """
        return format_data
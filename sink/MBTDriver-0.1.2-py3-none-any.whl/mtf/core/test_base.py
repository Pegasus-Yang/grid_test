# from core.logger import log
from mtf.core.context import Context
from mtf.core.testcase import TestCase
from mtf.core.testcasestore import TestCaseStore


class TestBase(object):
    context: Context = None

    def setup_class(self):
        self.context.run_steps(self.context.store.setup_class)

    def setup(self):
        self.context.run_steps(self.context.store.setup)

    def teardown(self):
        self.context.run_steps(self.context.store.teardown)

    def teardown_class(self):
        self.context.run_steps(self.context.store.teardown_class)

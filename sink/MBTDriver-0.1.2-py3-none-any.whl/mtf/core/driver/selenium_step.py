import importlib
from time import sleep

import allure
from selenium import webdriver
from selenium.common.exceptions import NoAlertPresentException
from selenium.webdriver import DesiredCapabilities, ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.select import Select
from selenium.webdriver.support.wait import WebDriverWait

import mtf.core.step


def deal_elements(function):
    """
    装饰器，将单元素操作扩展为多元素操作，方便对找到的一组元素进行同样的处理
    :param function: 需要被扩展的方法，该方法的第二个参数需要是被操作的元素
    :return:
    """

    def addon(*args, **kwargs):
        self: SeleniumStep = args[0]
        args_list = list(args)
        if len(self.get_elements()) == 1:
            # 将待操作元素插入参数列表中，传递给具体的处理方法进行操作
            args_list.insert(1, self.get_elements()[0])
            # 保存操作前的window_handle列表
            old_windows = self.get_driver().window_handles
            res = function(*args_list, **kwargs)
            # 保存操作后的window_handle列表
            new_windows = self.get_driver().window_handles
            # 如果操作前后window_handle列表无变化，直接返回
            if set(old_windows) == set(new_windows):
                return res
            # 如果操作后window_handle列表出现新元素，说明有新窗口打开，切换到新窗口
            diff = set(new_windows) - set(old_windows)
            if len(diff) >= 1:
                self.get_driver().switch_to.window(list(diff)[-1])
                return res
            else:
                self.get_driver().switch_to.window(list(new_windows)[-1])
                return res
        result = []
        for element in self.get_elements():
            args_list = list(args)
            # 将待操作元素插入参数列表中，传递给具体的处理方法进行操作
            args_list.insert(1, element)
            # 保存操作前的window_handle列表
            old_windows = self.get_driver().window_handles
            old_url = self.get_driver().current_url
            res = function(*args_list, **kwargs)
            result.append(res)
            # 保存操作后的window_handle列表
            new_windows = self.get_driver().window_handles
            # 如果操作前后window_handle列表无变化，直接返回
            if set(old_windows) == set(new_windows):
                if self.get_driver().current_url == old_url:
                    continue
                else:
                    return result
            # 如果操作后window_handle列表出现新元素，说明有新窗口打开，切换到新窗口，同时终止多元素操作
            diff = set(new_windows) - set(old_windows)
            if len(diff) >= 1:
                self.get_driver().switch_to.window(list(diff)[-1])
                return result
            else:
                self.get_driver().switch_to.window(new_windows[-1])
                return result
        return result

    return addon


class SeleniumStep(mtf.core.step.Step):
    _driver: WebDriver = None

    def __init__(self, dicts={}):
        self._black_num = 0
        super().__init__(dicts)

    def set_driver(self, driver):
        """
        在全局变量表中保存driver,保证操作相同的driver
        :param driver:
        :return:
        """
        self.get_context().global_dict['_selenium_driver'] = driver

    def get_driver(self) -> WebDriver:
        """
        从全局变量表中读取driver，保证操作相同的driver
        :return:
        """
        return self.get_context().global_dict['_selenium_driver']

    def set_elements(self, elements):
        """
        保存找到的elements元素对象列表，方便之后对其进行操作
        :param elements:
        :return:
        """
        self.get_context().global_dict['_selenium_elements'] = elements

    def get_elements(self):
        """
        获取保存的elements元素对象列表
        :return:
        """
        return self.get_context().global_dict['_selenium_elements']

    def set_black_list(self, black_list):
        """
        保存黑名单列表，用于每次操作时进行黑名单排查
        :param black_list:
        :return:
        """
        self.get_context().global_dict['_selenium_black_list'] = black_list

    def get_black_list(self):
        """
        获取保存的黑名单列表
        :return:
        """
        return self.get_context().global_dict.get('_selenium_black_list', None)

    def set_imp_time(self, imp_time):
        """
        保存隐式等待设置时间，在需要调整隐式等待时间的时候可以用于还原设置
        :param imp_time:
        :return:
        """
        self.get_context().global_dict['_selenium_imp_time'] = imp_time

    def get_imp_time(self):
        """
        获取隐式等待的设置时间
        :return:
        """
        return self.get_context().global_dict.get('_selenium_imp_time', None)

    def selenium(self, server=None, browser='chrome', window_size=None, imp_time=10, black_list=None, **kwargs):
        """
        通过Selenium启动本地/远程浏览器
        :param server: 远程服务器地址，如果为空则进行本机运行，直接启动对应浏览器
        :param browser: 浏览器类型
        :param window_size: 浏览器窗口大小，为空则默认最大化
        :param imp_time: 隐式等待时间，不设置默认10秒
        :param black_list: 黑名单，在每步操作前进行扫描，保证执行时不被意外情况干扰
        :return:
        """
        # 根据server和browser启动对应的浏览器
        browser = browser.upper()
        if server:
            if browser == 'IE':
                browser = 'INTERNETEXPLORER'
            desired = getattr(DesiredCapabilities, browser).update(kwargs)
            driver = webdriver.Remote(server, desired_capabilities=desired)
        else:
            # 动态导入selenium中浏览器对应的WebDriver类，驱动对应的本地浏览器
            webdriver_module = importlib.import_module(f'selenium.webdriver.{browser.lower()}.webdriver')
            driver = getattr(webdriver_module, 'WebDriver')(desired_capabilities=kwargs)
        # 设置浏览器大小
        if isinstance(window_size, list):
            driver.set_window_size(*window_size)
        else:
            driver.maximize_window()
        # 设置隐式等待时间
        driver.implicitly_wait(imp_time)
        self.set_imp_time(imp_time)
        if black_list:
            self.set_black_list(black_list)
        self.set_driver(driver)

    def get(self, url):
        """
        浏览器中打开URL地址
        :param url: 打开的URL地址
        :return:
        """
        self.get_driver().get(url)

    def find(self, locator, *args):
        """
        根据定位查找并返回一个元素，并将其存入全局变量表
        :param locator:
        :param args:
        :return:
        """
        if isinstance(locator, (list, tuple)):
            self._deal_black_list()
            self.wait(locator)
            element = self.get_driver().find_element(locator[0], locator[1])
            self.set_elements([element])
            return element
        else:
            self._deal_black_list()
            self.wait((locator, args[0]))
            element = self.get_driver().find_element(locator, args[0])
            self.set_elements([element])
            return element

    def finds(self, locator, *args):
        """
        根据定位查找并返回一组元素，并将其存入全局变量表
        :param locator:
        :param args:
        :return:
        """
        if isinstance(locator, (list, tuple)):
            self._deal_black_list()
            self.wait(locator)
            elements = self.get_driver().find_elements(locator[0], locator[1])
            self.set_elements(elements)
            return elements
        else:
            self._deal_black_list()
            self.wait((locator, args[0]))
            elements = self.get_driver().find_elements(locator, args[0])
            self.set_elements(elements)
            return elements

    def id(self, value):
        return self.finds(By.ID, value)

    def xpath(self, value):
        return self.finds(By.XPATH, value)

    def css(self, value):
        return self.finds(By.CSS_SELECTOR, value)

    def class_name(self, value):
        """
        为了避免原本selenium中class_name定位使用的css定位，
        导致元素有多个class时，直接复制class属性进行查询会报错。
        所以改用xpath表达式进行定位
        :param value:
        :return:
        """
        return self.finds(By.XPATH, f'//*[@class="{value}"]')

    def link_text(self, value):
        return self.finds(By.LINK_TEXT, value)

    def partial_link_text(self, value):
        return self.finds(By.PARTIAL_LINK_TEXT, value)

    def name(self, value):
        return self.finds(By.NAME, value)

    def tag_name(self, value):
        return self.finds(By.TAG_NAME, value)

    def text(self, value, tag_name=None):
        """
        通过xpath的string方法获取元素中的文字，通过该文字定位元素
        可以和标签名组合进行定位，方便缩小定位范围
        :param tag_name:  标签名，非必输
        :param value:  元素中的文字内容
        :return:
        """
        if tag_name:
            return self.finds(By.XPATH, f'//{tag_name}[string()="{value}"]')
        else:
            return self.finds(By.XPATH, f'//*[string()="{value}"]')

    def xpath_attr(self, attr, value):
        """
        通过给定元素的属性和属性值，定位元素
        :param attr: 属性名
        :param value: 属性值
        :return:
        """
        return self.xpath(f'//*[@{attr}="{value}"]')

    def xpath_attr_contains(self, attr, value):
        """
        通过给定元素的属性，通过模糊查询属性值，定位元素
        :param attr: 属性名
        :param value: 属性值
        :return:
        """
        return self.xpath(f'//*[contains(@{attr},"{value}")]')

    def xpath_no_wait(self, value):
        """
        去掉显式等待的xpath定位方式，可以根据返回列表的长度做页面中元素是否存在的判断
        :param value: xpath表达式
        :return:
        """
        self._deal_black_list()
        elements = self.get_driver().find_elements('xpath', value)
        self.set_elements(elements)
        return elements

    @deal_elements
    def click(self, element: WebElement):
        """
        点击元素
        :return:
        """
        self._deal_black_list()
        element.click()

    @deal_elements
    def clear(self, element: WebElement):
        """
        清除输入框中的内容
        :return:
        """
        self._deal_black_list()
        self.get_driver().execute_script('arguments[0].removeAttribute("readonly")', element)
        element.clear()

    @deal_elements
    def send_keys(self, element: WebElement, text):
        """
        向元素中输入内容
        :param text: 要输入的字符串
        :return:
        """
        self._deal_black_list()
        self.get_driver().execute_script('arguments[0].removeAttribute("readonly")', element)
        element.send_keys(text)

    @deal_elements
    def send_sys_keys(self, element: WebElement, key_name: str):
        """
        输入系统按钮操作，例如enter、backspace等
        :param key_name: 要输入的系统按键名称
        :return:
        """
        self._deal_black_list()
        self.get_driver().execute_script('arguments[0].removeAttribute("readonly")', element)
        key = getattr(Keys, key_name.upper())
        element.send_keys(key)

    @deal_elements
    def move_to(self, element: WebElement):
        """
        为了防止两次move_to的目标在相同区域，可能会导致无法触发JS事件，中间添加一步移动到别处的步骤
        :return:
        """
        self._deal_black_list()
        driver = self.get_driver()
        ActionChains(driver).move_to_element(driver.find_element(By.XPATH, '//*')).move_to_element(element).perform()

    def scroll(self, x, y):
        """
        支持输入浏览器大小百分比进行页面滚动，或者是直接输入
        :param x: 浏览器滚动的横坐标值/百分比
        :param y: 浏览器滚动的纵坐标值/百分比
        :return:
        """
        self._deal_black_list()
        driver = self.get_driver()
        size = driver.get_window_size()
        if str(x).endswith('%'):
            x = int(size['width'] * float(x[:-1]) / 100)
        if str(y).endswith('%'):
            y = int(size['height'] * float(y[:-1]) / 100)
        self.get_driver().execute_script(f'window.scrollBy({x}, {y})')

    def pop(self, choice: str, type: str = None):
        """
        处理弹出框，如果类型为alert,判断选项，进行对应处理，
        默认不作为alert处理，而是作为正常元素，通过xpath定位文字选择元素点击
        :param choice: 选择的选项
        :param type: 非必输，定义弹出框的类型，默认为普通界面元素，如果是alert则写alert
        :return:
        """
        self._deal_black_list()
        driver = self.get_driver()
        if type and type.lower() == 'alert':
            WebDriverWait(self.get_driver(), 10).until(self._is_alert_show)
            if choice.lower() in ['是', '确定', 'yes', '好']:
                driver.switch_to.alert.accept()
            elif choice.lower() in ['否', '取消', 'no', '关闭', '不好']:
                driver.switch_to.alert.dismiss()
            else:
                alert = driver.switch_to.alert
                alert.send_keys(choice)
                alert.accept()
        else:
            self.text(choice)
            self.click()

    @deal_elements
    def get_attribute(self, element: WebElement, name):
        """
        获取元素指定属性的值，属性名通过name指定
        :param name: 属性名
        :return:
        """
        self._deal_black_list()
        return element.get_attribute(name)

    def sleep(self, time=1):
        sleep(time)

    def quit(self):
        self.get_driver().quit()

    def close(self):
        self.get_driver().close()
        self.switch_window()

    def switch_frame(self, locator=None):
        """
        切换到特定frame,可以先定位到需要切换的frame或者直接通过id/name属性切换到对应的frame中
        :param locator:
        :return:
        """
        if locator is None:
            self.get_driver().switch_to.frame(self.get_elements()[-1])
        else:
            self.get_driver().switch_to.frame(locator)

    def switch_out_frame(self, default=False):
        """
        跳出当前frame
        :param default:
        :return:
        """
        if default:
            self.get_driver().switch_to.default_content()
        else:
            self.get_driver().switch_to.parent_frame()

    def switch_window(self, window_handle=None):
        """
        切换窗口句柄，默认是切换至最新的窗口
        :param window_handle: 窗口句柄id，可以切换到指定窗口
        :return:
        """
        if window_handle is None:
            self.get_driver().switch_to.window(self.get_driver().window_handles[-1])
        else:
            self.get_driver().switch_to.window(window_handle)

    def wait(self, locator=None, attr='clickable', wait_time=10):
        """
        对元素进行显式等待，如果不传入定位则对之前定位到的元素进行等待
        :param locator: 元素定位
        :param attr: 等待方法
        :param wait_time: 等待超时时间
        :return:
        """
        driver = self.get_driver()

        def _wait_until(func):
            driver.implicitly_wait(0.5)
            WebDriverWait(driver, wait_time).until(func)
            driver.implicitly_wait(self.get_imp_time())

        if locator is None:
            if attr.lower() == 'clickable':
                _wait_until(self._is_clickable)
            elif attr.lower() == 'visible':
                _wait_until(self._is_visible)
        else:
            if attr.lower() == 'clickable':
                _wait_until(expected_conditions.element_to_be_clickable(locator))
            elif attr.lower() == 'visible':
                _wait_until(expected_conditions.visibility_of_element_located(locator))
            elif attr.lower() == 'url_contains':
                _wait_until(expected_conditions.url_contains(locator))
            elif attr.lower() == 'wait_invisible':
                _wait_until(expected_conditions.invisibility_of_element(locator))

    def select(self, value):
        """
        根据传入的数据进行选择框的操作，如果参数是数字就根据顺序选取，如果是字符串就根据列表展示文字选取
        :param value: 选择的选项
        :return:
        """
        self._deal_black_list()
        if isinstance(value, int):
            Select(self.get_elements()).select_by_index(value)
        elif isinstance(value, str):
            Select(self.get_elements()).select_by_visible_text(value)

    @deal_elements
    def get_text(self, element: WebElement):
        """
        获取元素的text值
        :return:
        """
        self._deal_black_list()
        return element.text

    def get_url(self):
        """
        获取当前页面的url地址
        :return:
        """
        return self.get_driver().current_url

    def get_title(self):
        """
        获取当前页面的title数据
        :return:
        """
        return self.get_driver().title

    def screen_shot(self, name='截图'):
        """
        进行截图并将其作为附件添加到allure报告中
        :param name: 附件名称，默认为 截图
        :return:
        """
        allure.attach(self.get_driver().get_screenshot_as_png(), name, allure.attachment_type.PNG)

    def _is_clickable(self, element: WebElement) -> bool:
        """
        判断元素是否在页面显示、是否可用
        :return:
        """
        if element.is_displayed() and element.is_enabled():
            return True
        return False

    def _is_visible(self, element: WebElement) -> bool:
        """
        判断元素是否在页面显示
        :return:
        """
        if element.is_displayed():
            return True
        return False

    def _is_alert_show(self) -> bool:
        """
        判断是否出现了alert弹框
        :return:
        """
        try:
            self.get_driver().switch_to.alert()
            return True
        except NoAlertPresentException:
            return False

    def _deal_black_list(self):
        """
        处理黑名单元素
        :return:
        """
        driver = self.get_driver()
        driver.implicitly_wait(0.5)
        black_list = self.get_black_list()
        if black_list:
            for line in black_list:
                if line[2].lower() == 'wait_invisible':
                    self.wait((line[0], line[1]), 'wait_invisible')
                elif line[2].lower() == 'click':
                    elements = self.get_driver().find_elements(line[0], line[1])
                    if len(elements) > 0:
                        elements[0].click()
        driver.implicitly_wait(self.get_imp_time())

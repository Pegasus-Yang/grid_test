import re
from json.decoder import JSONDecodeError
from typing import Union

from jsonpath import jsonpath

from mtf.core.driver.request import Request
from mtf.core.driver.sql import MySQL, Oracle, SQL
from mtf.core.step import Step


class RequestsStep(Step):

    def __init__(self, dict={}):
        super().__init__(dict)

    def _set_session(self, session):
        self.get_context().global_dict['_requests_session'] = session

    def _get_session(self) -> Request:
        return self.get_context().global_dict.get('_requests_session', None)

    def _set_response(self, response):
        self.get_context().global_dict['_requests_response'] = response

    def _get_response(self) -> list:
        return self.get_context().global_dict.get('_requests_response', None)

    def _set_sql_conn(self, sql_conn):
        self.get_context().global_dict['_requests_sql_conn'] = sql_conn

    def _get_sql_conn(self) -> Union[SQL, None]:
        return self.get_context().global_dict.get('_requests_sql_conn', None)

    def _set_sql_result(self, sql_result):
        self.get_context().global_dict['_requests_sql_result'] = sql_result

    def _get_sql_result(self):
        return self.get_context().global_dict.get('_requests_sql_result', None)

    def mysql(self, *args, **kwargs):
        mysql = MySQL(*args, **kwargs)
        self._set_sql_conn(['mysql', mysql])

    def oracle(self, *args, **kwargs):
        oracle = Oracle(*args, **kwargs)
        self._set_sql_conn(['oracle', oracle])

    def sql_execute(self, sql: str, params=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            if sql_conn[0] in ['mysql', 'oracle']:
                sql_object = sql_conn[1]
                return sql_object.execute(sql, params)
        else:
            raise Exception('No sql Connection')

    def sql_commit(self):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            if sql_conn[0] in ['mysql', 'oracle']:
                sql_object = sql_conn[1]
                sql_object.close_cursor()
                sql_object.commit()
        else:
            raise Exception('No sql Connection')

    def sql_result(self, num=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            res = sql_conn[1].result(num)
            self._set_sql_result(res)
            return res
        else:
            raise Exception('No sql Connection')

    def sql_rollback(self):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            sql_conn[1].rollback()
        else:
            raise Exception('No sql Connection')

    def sql_select(self, sql, params=None, result_num=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            res = sql_conn[1].select(sql, params, result_num)
            self._set_sql_result(res)
            return res
        else:
            raise Exception('No sql Connection')

    def sql_update(self, sql, params=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            sql_conn[1].update(sql, params)
        else:
            raise Exception('No sql Connection')

    def sql_delete(self, sql, params=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            sql_conn[1].delete(sql, params)
        else:
            raise Exception('No sql Connection')

    def sql_insert(self, sql, params=None):
        sql_conn = self._get_sql_conn()
        if sql_conn:
            sql_conn[1].insert(sql, params)
        else:
            raise Exception('No sql Connection')

    def requests(self, base_url=None):
        if not self._get_session():
            self._set_session(Request(base_url))

    def new_session(self):
        self._get_session().new_session()

    def request(self, method, url='', skip_list=None, **kwargs):
        res = self._get_session().request(method, url, skip_list, **kwargs)
        try:
            res = res.json()
            self._set_response(['json', res])
        except JSONDecodeError:
            res = res.text
            self._set_response(['text', res])
        return res

    def get(self, url='', **kwargs):
        return self.request('get', url=url, **kwargs)

    def post(self, url='', **kwargs):
        return self.request('post', url=url, **kwargs)

    def delete(self, url='', **kwargs):
        return self.request('delete', url=url, **kwargs)

    def put(self, url='', **kwargs):
        return self.request('put', url=url, **kwargs)

    def head(self, url='', **kwargs):
        return self.request('head', url=url, **kwargs)

    def patch(self, url='', **kwargs):
        return self.request('patch', url=url, **kwargs)

    def options(self, url='', **kwargs):
        return self.request('options', url=url, **kwargs)

    def get_res(self, path: str):
        """
        根据表达式获取上次接口返回中的数据，支持jsonpath和正则表达式
        :param path: jsonpath表达式或者正则表达式
        :return: 获取到的数据，无结果则返回False
        """
        res = self._get_response()[1]
        return self._extrace_data(res, path)

    def get_sql_res(self, path: str):
        """
        根据表达式获取上次sql查询语句返回的数据，支持jsonpath
        :param path: jsonpath表达式
        :return: 获取到的数据，无结果则返回False
        """
        res = self._get_sql_result()
        return self._extrace_data(res, path)

    def _extrace_data(self, res, pattern):
        if res:
            if pattern.startswith('$'):
                result = jsonpath(res, pattern)
            else:
                result = re.findall(pattern, str(res))
            if result:
                if len(result) == 1:
                    return result[0]
                return result
        return False

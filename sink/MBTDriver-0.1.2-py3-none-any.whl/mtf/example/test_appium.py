import pytest

# from core.logger import log
from mtf.core import TestCase
from mtf.core import TestCaseStore
from mtf.core.utils import Utils


class TestBasic:
    store = TestCaseStore().load(Utils.get_project_dir() + "/tests/test_appium.yaml")

    def setup_class(self):
        pass

    def setup(self):
        pass

    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        store.testcases.values(),
        ids=store.testcases.keys()
    )
    def test_param(self, testcase):
        TestCase(testcase).run_steps()

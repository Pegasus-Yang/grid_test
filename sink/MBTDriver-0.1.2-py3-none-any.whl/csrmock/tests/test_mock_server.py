from mitmproxy import http

from csrmock.core.mock_server import MockServer
from csrmock.core.protocol.protocol_demo import ProtocolDemo
from csrmock.core.protocol.protocol_json import ProtocolJson
from mtf.core.utils import Utils


class TestMock:
    def setup(self):
        self.mock_server = MockServer()

    def test_mock_simple(self):
        self.mock_server.add_mock('123', 'mock 123', 'simple')
        self.mock_server.add_mock('1234', 'mock 1234', 'simple')
        res = self.mock_server.mock('123', None)
        assert res == 'mock 123'

        res = self.mock_server.mock('1234', None)
        assert res == 'mock 1234'

        res = self.mock_server.mock('12345', None)
        assert res == None

    def test_mock_data(self):
        self.mock_server.set_protocol('demo')
        self.mock_server.add_mock('$..[?(@.req=="demo req")]', {'res': 'mock success'})
        self.mock_server.add_mock('$..[?(@.req=="demo req")]', {'res': 'mock success'})

        r = self.mock_server.mock({'req': 'demo req'}, None)
        assert r == {'res': 'mock success'}

    def test_mock_json(self):
        mock_data = 'mock testcase'
        self.mock_server.add_mock(
            '$..[?(@.method=="POST")]',
            {'data': mock_data},
            'json'
        )
        r: http.HTTPResponse = self.mock_server.mock(ProtocolJson.get_demo_req(), None)
        print(Utils.to_json_str(r))
        assert Utils.to_json_object(r.text)['data'] == mock_data

    def test_add_protocol(self):
        self.mock_server.add_mock(protocol=ProtocolDemo, req_matcher='aa', res=None)
        assert self.mock_server.mock_rules[-1].req_matcher == 'aa'

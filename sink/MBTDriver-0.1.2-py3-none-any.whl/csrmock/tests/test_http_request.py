import json

from jsonpath import jsonpath
from mitmproxy import http

from csrmock.core.protocol.protocol_json import ProtocolJson


def test_decode_req():
    request = http.HTTPRequest(
        first_line_format="",
        method="get",
        scheme="http",
        host='127.0.0.1',
        port=80,
        path='/',
        http_version=2.0,
        headers={},
        content=None,
    )
    http_req = ProtocolJson(req_matcher='$..[?(@.method=="get")]', res_mock=None)
    if http_req.hit(request):
        print("True")
        assert True
    else:
        print("False")
        assert False


def test_json_path():
    d = """
    [{"first_line_format": "", "method": "get", "scheme": "http", "host": "127.0.0.1", "port": 80, "path": "/", "http_version": 2.0, "headers": {"fields": []}, "content": null, "trailers": null, "timestamp_start": null, "timestamp_end": null}]
    """
    print(jsonpath(json.loads(d), '$..[?(@.method=="get")]'))

    d = '''
    [{"first_line_format": "relative", "method": "GET", "scheme": "http", "host": "127.0.0.1", "port": 8000, "path": "/3", "http_version": "HTTP/1.1", "headers": {"fields": [["Host", "127.0.0.1"], ["User-Agent", "curl/7.54.0"], ["Accept", "*/*"]]}, "content": "", "trailers": null, "timestamp_start": 1598297465.120235, "timestamp_end": 1598297465.121639}]
    '''
    print(jsonpath(json.loads(d), '$..[?(@.method==GET)]'))

from csrmock.core.protocol.protocol_message import ProtocolMessage


def test_filter():
    msg = ProtocolMessage(req_matcher={'a': 1, 'b': '2'})
    msg.filter()

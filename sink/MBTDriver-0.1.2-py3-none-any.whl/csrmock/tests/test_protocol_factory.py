from csrmock.core.mock_server import MockServer
from csrmock.core.protocol.protocol_demo import ProtocolDemo
from csrmock.core.protocol.protocol_factory import ProtocolFactory


def test_get_mock_object():
    f = ProtocolFactory()
    r = f.get_mock_object(protocol=ProtocolDemo, req_matcher='aa', res_mock=None)
    assert r.req_matcher == 'aa'


def test_get_mock_object_package_class():
    f = ProtocolFactory()
    r = f.get_mock_object(
        protocol='csrmock.core.protocol.protocol_demo.ProtocolDemo',
        req_matcher='aa',
        res_mock=None)
    assert r.req_matcher == 'aa'

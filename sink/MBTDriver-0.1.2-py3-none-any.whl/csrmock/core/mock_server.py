from time import sleep
from typing import List

import requests

from csrmock.core.protocol.protocol_factory import ProtocolFactory
from csrmock.core.protocol.protocol_message import ProtocolMessage
from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.utils import Singleton


@Singleton
class MockServer:
    '''
    mock逻辑的驱动引擎，根据请求分发给各个mock实现链
    '''

    def __init__(self):
        self.protocol = None
        # mock历史记录
        self.history = []
        # mock规则，协议实现的列表，可以不同
        self.mock_rules: List[ProtocolMessage] = []
        self.mtf = Context()
        self.config = {}

    def set_protocol(self, protocol):
        '''
        设置默认协议
        :param protocol:
        :return:
        '''
        self.protocol = protocol

    def mock_request(self):
        pass

    def mock_response(self):
        pass

    def add_mock(self, req_matcher, res, protocol=None, config=None):
        '''
        添加mock规则
        :param req_matcher:
        :param res:
        :param protocol:
        :return:
        '''
        if protocol is None:
            protocol = self.protocol
        mock_rule = ProtocolFactory.get_mock_object(protocol, req_matcher, res, config)
        self.mock_rules.append(mock_rule)

    def is_forward(self, req):
        """
        对 req 进行判断，是否进行转发，如果规则不匹配，进行转发
        :return:
        """
        for rule in self.mock_rules:
            if rule.filter():
                return rule.is_forward(req)
        return True

    def mock(self, req, res):
        '''
        如果mock匹配，就直接返回编码后的mock结果
        :param req:
        :param res:
        :return:
        '''
        for rule in self.mock_rules:
            if rule.config.get('limit', -1) == 0:
                log.debug(f'rule ${rule} skip')
                continue

            if not rule.is_me(req):
                continue

            res_mock = rule.hit(req)
            if res_mock is not None:
                if 'wait' in rule.config:
                    wait_key = rule.config.get('wait')
                    while True:
                        log.debug(f'config={self.config} wait_key={wait_key}')
                        if self.config.get(wait_key, False):
                            break
                        sleep(0.2)

                if 'action' in rule.config and len(rule.config.get('action')) > 0:
                    # todo: 把执行从mock server转移到测试用例中
                    log.info('action run')
                    r = self.mtf.run_steps_by_dict(rule.config.get('action'))
                    log.debug(f'action result {r}')
                    # todo: 支持与case互动
                    # r=requests.get(
                    #     'http://127.0.0.1:8008/hook',
                    #     json={
                    #         'req': None,
                    #         'config': rule.config.get('action')
                    #     }
                    # )
                    # log.debug(r.text)

                log.debug("mock")
                log.debug(res_mock)

                return res_mock
            else:
                log.debug("no mock")
        return res

    def reset(self):
        '''
        重置数据
        :return:
        '''
        self.history = []
        self.mock_rules = []

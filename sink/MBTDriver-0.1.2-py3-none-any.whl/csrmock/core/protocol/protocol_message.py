from jsonpath import jsonpath

from mtf.core.logger import log
from mtf.core.utils import Utils


class ProtocolMessage:
    def __init__(self, req_matcher=None, res_mock=None, config=None):
        '''
        :param req_matcher: 判断是否需要mock，如果这个表达式执行结果为真，就进行mock
        :param res_mock: 当mock匹配的时候，返回一个预期的res_mock
        '''
        self.req_matcher = req_matcher
        # python结构体，表示mock res
        self.res = res_mock
        # python结构体，表示请求对应的数据格式
        self.req = None
        if config is not None:
            self.config = config
        else:
            self.config = {
                'limit': -1,
                'action': []
            }

    def encode_res(self):
        '''
        当mock生效的时候，把原始的python结构体表示的res_mock编码成具体的协议的消息，比如二进制
        :return:
        '''
        return self.res

    def decode_req(self, req):
        '''
        把真实请求比如二进制解析为一个python标准结构
        :param req:
        :return:
        '''
        self.req = req
        return self.req

    def decode_res(self, res):
        '''
        把返回结果比如二进制解析为一个python标准结构
        :param req:
        :return:
        '''
        self.res = res
        return self.res

    def filter(self):
        if isinstance(self.req_matcher, dict):
            expr = []
            for key, value in self.req_matcher.items():
                expr.append(f'@.{key} == {repr(value)}')
            self.req_matcher = f"$..[?({' and '.join(expr)})]"
        else:
            pass
        log.debug(self.req_matcher)
        log.debug(self.req)
        log.debug(Utils.to_json_object([self.req]))
        return jsonpath(Utils.to_json_object([self.req]), self.req_matcher)

    def is_me(self, req_real: bytes):
        '''
        识别是否是自己的协议
        :param req_real:
        :return:
        '''
        return True

    def hit(self, req_real, matcher=None):
        '''
        判断是否命中，把任意结构转成json，使用jsonpath去匹配
        尽量别重载这个方法

        :param req_real:
        :return:
        '''
        # 把真实数据解码为标准结构
        self.req = self.decode_req(req_real)
        if self.filter():
            if 'limit' in self.config:
                self.config['limit'] -= 1
            return self.encode_res()
        else:
            return None

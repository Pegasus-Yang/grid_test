from csrmock.core.protocol.protocol_message import ProtocolMessage


class ProtocolDemo(ProtocolMessage):
    def encode_res(self):
        return self.res

    def decode_req(self, req):
        self.req = req
        return self.req

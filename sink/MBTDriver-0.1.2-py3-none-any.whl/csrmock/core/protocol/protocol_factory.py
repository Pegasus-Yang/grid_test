import importlib

from csrmock.core.protocol.protocol_demo import ProtocolDemo
from csrmock.core.protocol.protocol_json import ProtocolJson
from csrmock.core.protocol.protocol_message import ProtocolMessage
from csrmock.core.protocol.protocol_simple import ProtocolSimple
from csrmock.core.protocol.protocol_tcp import ProtocolTcp
from mtf.core.logger import log


class ProtocolFactory:

    @classmethod
    def get_mock_object(cls, protocol, req_matcher=None, res_mock=None, config=None):
        # todo: add tcp support
        # todo：工厂方法
        params = {'req_matcher': req_matcher, 'res_mock': res_mock, 'config': config}
        if protocol == 'json':
            return ProtocolJson(**params)
        elif protocol == 'simple':
            return ProtocolSimple(**params)
        elif protocol == 'mmi':
            return ProtocolTcp(**params)
        elif protocol == 'demo':
            return ProtocolDemo(**params)
        elif protocol == 'at':
            pass
        elif not isinstance(protocol, str) and issubclass(protocol, ProtocolMessage):
            return protocol(**params)
        # todo: 支持从目录下扫描协议扩展
        else:
            try:
                array = str(protocol).split('.')
                package_name = '.'.join(array[0:-1])
                class_name = array[-1]
                module = importlib.import_module(package_name)
                return getattr(module, class_name)(**params)
            except Exception as e:
                raise e

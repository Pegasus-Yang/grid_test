import inspect
import os
import socket
import threading
from time import sleep

from mtf.core.logger import log
from mtf.core.singleton import Singleton
from mtf.core.utils import Utils
import asyncio


@Singleton
class EchoServer:

    def __init__(self):
        self.host = '127.0.0.1'  # Standard loopback interface address (localhost)
        self.port = 65432  # Port to listen on (non-privileged ports are > 1023)
        self.conn: socket.socket = None
        self.thread: threading.Thread = None
        self.stop_flag = False
        log.info(f"EchoServer init {self}")

    def start(self):
        log.info("EchoServer start")

        # def stop():
        #     self.stop_flag = True
        #
        # signal.signal(signal.SIGTERM, stop)
        # signal.signal(signal.SIGSTOP, stop)
        # signal.signal(signal.SIGKILL, stop)
        # signal.signal(signal.SIGABRT, stop)

        if self.conn is None:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                self.conn = s
                log.info(f"bind {s} ")
                s.bind((self.host, self.port))
                s.listen()

                while self.stop_flag == False:
                    conn, addr = s.accept()
                    log.debug(f'new connection {conn} {addr}')
                    with conn:
                        while self.stop_flag == False:
                            data = conn.recv(1024)
                            log.debug(f"recv {str(data)}")
                            if not data:
                                break
                            log.debug('sendall')
                            conn.sendall(data)
        else:
            pass

        log.debug(os.getpid())
        log.debug(os.getppid())
        return self.conn

    async def handle_echo(reader, writer):
        data = await reader.read(100)
        message = data.decode()
        addr = writer.get_extra_info('peername')

        print(f"Received {message!r} from {addr!r}")

        print(f"Send: {message!r}")
        writer.write(data)
        await writer.drain()

        print("Close the connection")
        writer.close()

    async def main(self):
        server = await asyncio.start_server(
            self.handle_echo, '127.0.0.1', 8888)

        addr = server.sockets[0].getsockname()
        print(f'Serving on {addr}')

        async with server:
            await server.serve_forever()

    def start_in_background(self):
        self.thread = threading.Thread(
            target=self.start
        )
        self.thread.daemon = True
        log.debug(self.thread)
        self.thread.start()

    def stop(self):
        self.stop_flag = True
        if self.conn is not None:
            self.conn.close()

    def start_in_async(self):
        asyncio.run(self.main())


class Forward:
    async def tcp_echo_client(self, message):
        reader1, writer1 = await asyncio.open_connection(
            '127.0.0.1', 7777)
        reader2, writer2 = await asyncio.open_connection(
            '127.0.0.1', 7778)

        data = await reader1.read(2)
        print(f'Received: {data.decode()!r}')
        writer1.write(data)
        #
        # print('Close the connection')
        # writer.close()

    def start(self):
        asyncio.run(self.tcp_echo_client('Hello World!'), debug=True)

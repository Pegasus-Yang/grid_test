from struct import unpack, pack

from mtf.core.logger import log
from csrmock.core.protocol.protocol_message import ProtocolMessage


class ProtocolBin(ProtocolMessage):
    schema = {
        'req': [
            {
                'name': 'f1',
                'type': 'hex',
                'default': '00',
                'size': 2
            },
            {
                'name': 'f2',
                'type': 'h',
                'default': '00'
            },
        ],
        'res': [

        ],
        'config': {
            'byte_order': '<'
        }
    }

    def encode_res(self):
        log.debug(self.res)
        format_str = ['<']
        format_value = []
        for r in self.res:
            if isinstance(r, int):
                format_str.append('h')
                format_value.append(r)
            elif isinstance(r, str):
                format_str.append(f'{len(r.encode())}s')
                format_value.append(r.encode())
        log.debug(format_str)
        byte_array = pack(''.join(format_str), *format_value)
        log.debug(byte_array)
        return byte_array

    def decode_req(self, req_real):
        if self.schema:
            format_str = ''
            byte_order = self.schema.get('config', {}).get('byte_order', '<')

            format_str += byte_order

            for field in self.schema['req']:
                name = field.get('name')
                type = field.get('type', 's')
                size = field.get('size', 1)
                default = field.get('default')
                if type in ['int', 'i']:
                    format_str += 'i'
                elif type in ['short', 'h']:
                    format_str += 'h'
                elif type in ['long', 'l']:
                    format_str += 'l'
                elif type in ['float', 'f']:
                    format_str += 'f'
                elif type in ['double', 'd']:
                    format_str += 'd'
                elif type in ['char', 'str', 'string', 's']:
                    format_str += 's' * size
                elif type in ['pad', 'x', 'null']:
                    format_str += 'x' * size
                # todo: more type

            log.debug(f'format_str={format_str}')

            data = {}
            index = 0
            for t in unpack(format_str, req_real):
                data[self.schema['req'][index]['name']] = t
                index += 1
            log.info(data)
            print(data)
            return data
        else:
            log.error("no schema")

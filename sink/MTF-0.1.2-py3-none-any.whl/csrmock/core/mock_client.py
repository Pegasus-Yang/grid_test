import requests

from mtf.core.logger import log


class MockClient:
    def __init__(self, url):
        self.url = url
        self.mock_address = '/'.join([self.url, 'core'])
        self.history_address = '/'.join([self.url, 'history'])
        self.config_address = '/'.join([self.url, 'config'])
        self.reset_address = '/'.join([self.url, 'reset'])

    def mock(self, req, res, protocol=None, config=None, schema=None):
        # todo: 暂时在客户端实现数据类型变更，后续转移到服务端实现

        r = requests.post(
            self.mock_address,
            json={
                'req': req,
                'res': res,
                'protocol': protocol,
                'config': config,
                'schema': schema,
            }
        )

        log.debug(f'{r.text}')
        assert r.status_code == 200
        return r.json()

    def history(self):
        r = requests.get(self.history_address)
        log.debug(f'{r.json()}')
        return r.json()

    def config(self, **kwargs):
        r = requests.post(self.config_address, json=kwargs)
        log.debug(f'{r.json()}')
        return r.json()

    def reset(self):
        r = requests.post(self.reset_address)
        log.debug(f'{r.json()}')
        return r.json()

from multiprocessing.context import Process
from time import sleep

import requests

from csrmock.core.mitm.mitm_json import MitmJson
from csrmock.core.mitm.mitm_tcp import MitmTcp
from csrmock.core.mock_client import MockClient
from csrmock.core.tcp_server_echo import EchoServer
from mtf.core.logger import log
from mtf.core.utils import Utils


class TestMitmJson:
    def setup_class(self):
        pass

    def test_main(self):
        client = MockClient(url='http://127.0.0.1:8004')
        print(client.reset())
        client.mock('$..[?(@.f1=="1")]', 'abc123')
        r = Utils.nc('127.0.0.1', 9102, '12345678')
        assert r.decode('utf-8') == 'abc123'
        #
        # client=MockClient(url='http://127.0.0.1:8002')
        # client.mock('$..[?(@.method=="POST")]', {'b': 2})
        # r=requests.post('http://127.0.0.1:8001/')
        # assert r.json()['b'] == 2

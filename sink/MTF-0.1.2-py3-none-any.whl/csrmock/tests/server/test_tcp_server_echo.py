import logging
import threading
from time import sleep

from _pytest.fixtures import FixtureRequest

from csrmock.core.mitm.mitm_json import MitmJson
from csrmock.core.mitm.mitm_tcp import MitmTcp
from csrmock.core.tcp_server_echo import Forward, EchoServer
from mtf.core.logger import log
from mtf.core.utils import Utils


def test_forward_start():
    f = Forward()
    # f.start()


# def test_start_in_background():
#     server = EchoServer()
#     server.start_in_background()
#     sleep(3)
#     r = Utils.nc('127.0.0.1', 65432, '123')
#     assert r.decode('utf-8') == '123'
#     server.conn.close()



def test_echo_server(request: FixtureRequest):
    p = Utils.process(target=MitmTcp.main)
    # p = Utils.process(target=MitmJson.main)
    log.debug(threading.current_thread().name)
    p.terminate()
    p.join()

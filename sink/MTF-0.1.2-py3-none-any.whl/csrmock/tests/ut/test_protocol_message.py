from csrmock.core.protocol.protocol_message import ProtocolMessage


def test_expr_python():
    msg = ProtocolMessage(
        req_matcher='python: "12" in req',
        res_mock='python: res=res[0:1]+"abc"+ res[2:]; '
    )
    res = msg.hit("123", "456")
    print(res)
    assert res == '4abc6'

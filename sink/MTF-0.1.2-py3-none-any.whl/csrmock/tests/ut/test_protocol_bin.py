from core.protocol.protocol_bin import ProtocolBin
from mtf.core.logger import log


def test_decode_req():
    schema = {
        'req': [
            {
                'name': 'f1',
                'type': 'int'
            }
        ],
        'config': {
            'byte_order': '<'
        }
    }
    bin = ProtocolBin(schema=schema)
    print(bin)
    log.debug('xxxx')
    req = bin.decode_req(b'\x01\x00\x00\x00')
    print(req)

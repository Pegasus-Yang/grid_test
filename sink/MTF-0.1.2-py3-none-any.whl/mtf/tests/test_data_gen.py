import pytest

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase
from mtf.core.utils import Utils


class TestCaseDemo(TestBase):
    context = Context()
    name = str(__name__).split('.')[-1] + '.yaml'
    log.debug(name)
    context.load(name)

    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        context.store.testcases.values(),
        ids=context.store.testcases.keys()
    )
    def test_param(self, testcase):
        self.context.run_steps_by_testcase(testcase)

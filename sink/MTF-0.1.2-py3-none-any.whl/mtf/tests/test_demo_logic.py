import pytest

from mtf.core.context import Context
from mtf.core.logger import log
from mtf.core.test_base import TestBase
from mtf.core.testcase import TestCase


class TestCaseDemo(TestBase):
    context = Context()
    context.load(str(__name__).split('.')[-1] + '.yaml')

    # done: testcase name
    @pytest.mark.parametrize(
        "testcase",
        [[k, v] for k, v in context.store.testcases.items()],
        ids=context.store.testcases.keys()
    )
    def test_param(self, testcase):
        name = testcase[0]
        steps = testcase[1]
        testcase = TestCase(steps, self.context)
        testcase.name = name
        testcase.run_steps()

    def teardown_class(self):
        self.context.tree.show(__file__)

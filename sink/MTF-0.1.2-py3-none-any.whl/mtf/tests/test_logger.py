import logging

from mtf.core.logger import log


def test_log():
    log.setLevel(logging.DEBUG)
    log.debug('111')
    log.info('1111')
    log.error('1111')

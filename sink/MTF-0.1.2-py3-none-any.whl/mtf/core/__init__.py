import math

# from xxxxx import *

# cloudate=CloudATE()

floor = math.floor

from appium import webdriver
from appium.webdriver.common.mobileby import MobileBy
from appium.webdriver.webdriver import WebDriver
from mtf.core.driver.selenium_step import SeleniumStep


class AppiumStep(SeleniumStep):
    def appium(self, server, caps):
        driver = webdriver.Remote(server, caps)
        self.set_driver(driver)
        self.get_driver().implicitly_wait(10)

    def aid(self, value):
        driver: WebDriver = self.get_driver()
        element = driver.find_element(MobileBy.ACCESSIBILITY_ID, value)
        self.set_element(element)

# Author:Pegasus-Yang
# Time:2020/11/9 7:26
import os

import psutil
process_id = ''
for p in psutil.process_iter(['pid','name']):
    if p.info['name'] == 'java.exe' and 'Clock' in ','.join(p.cmdline()):
        process_id = p.pid
        print(process_id)
cmd=''
os.popen()
rm -r allure-* debug.log junit*.xml
PYTHONPATH=../../../ python -m mtf "$@"
allure open allure-report
